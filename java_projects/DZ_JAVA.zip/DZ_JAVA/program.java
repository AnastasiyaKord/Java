package java_projects;

public class program {
    public static void main(String[] args) {
        System.out.println("worldddd");
    }
}
