package java_projects.DZ_JAVA;

public class Answer {

    public int factorial(int n) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'factorial'");
    }

    public void printEvenNums() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'printEvenNums'");
    }

    public int sumDigits(int n) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'sumDigits'");
    }

    public int findMaxOfThree(int a, int b, int c) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findMaxOfThree'");
    }

}
